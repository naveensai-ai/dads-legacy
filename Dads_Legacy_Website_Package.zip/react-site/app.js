const e=React.createElement;
function App(){return e('div',{style:{color:'gold',background:'black',padding:'20px',textAlign:'center'}},[
    e('img',{src:'assets/logo.png',style:{width:'150px'}}),
    e('h1',null,"Dad's Legacy React Site")
]);}
ReactDOM.render(e(App),document.getElementById('root'));